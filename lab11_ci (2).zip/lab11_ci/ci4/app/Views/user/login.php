<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" href="<?= base_url('/style.css');?>">
<style type="text/css">
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    width: 300px;
}
h2 {
    text-align: center;
    color: #333;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #555;
}

input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background-color: #5cb85c; 
    color: white;
    border: none;
    padding: 10px;
    border-radius: 4px;
    cursor: pointer;
    width: 40%;
}

button:hover {
    background-color: #4cae4c; 
}
</style>
</head>
<body>
<div id="login-wrapper">
<h1>Sign In</h1>
<?php if(session()->getFlashdata('flash_msg')):?>
<div class="alert alert-danger"><?= session()->getFlashdata('flash_msg') ?></div>
<?php endif;?>
<form action="" method="post">
<div class="mb-3">
<label for="InputForEmail" class="form-label">Email
address</label>
<input type="email" name="email" class="form-control"
id="InputForEmail" value="<?= set_value('email') ?>">
</div>
<div class="mb-3">

<label for="InputForPassword" class="form-
label">Password</label>

<input type="password" name="password" class="form-
control" id="InputForPassword">

</div>
<button type="submit" class="btn btn-primary">Login</button>
</form>
</div>
</body>
</html>