<?= $this->include('template/admin_header'); ?>

<div class="container mt-4">
    <h2><?= esc($title); ?></h2>

    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <li><?= esc($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="" method="post" class="mt-3">
        <?= csrf_field(); ?>

        <!-- Judul -->
        <div class="mb-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" class="form-control" id="judul" name="judul" value="<?= old('judul'); ?>" placeholder="Masukkan judul" required>
        </div>

        <!-- Isi -->
        <div class="mb-3">
            <label for="isi" class="form-label">Isi</label>
            <textarea class="form-control" id="isi" name="isi" rows="5" placeholder="Tulis isi di sini..." required><?= old('isi'); ?></textarea>
        </div>

        <!-- Kategori -->
        <div class="mb-3">
            <label for="id_kategori" class="form-label">Kategori</label>
            <select class="form-select" id="id_kategori" name="id_kategori" required>
                <option value="" disabled <?= old('id_kategori') ? '' : 'selected' ?>>-- Pilih Kategori --</option>
                <option value=""  <?= old('id_kategori') ? '' : 'selected' ?>>Pemograman</option>
                <option value=""  <?= old('id_kategori') ? '' : 'selected' ?>>Teknologi</option>
                <option value=""  <?= old('id_kategori') ? '' : 'selected' ?>>Lifestyle</option>
                <?php if (!empty($kategori) && is_array($kategori)): ?>
                    <?php foreach ($kategori as $kat): ?>
                        <?php if (isset($kat['id']) && isset($kat['nama_kategori'])): ?>
                            <option value="<?= esc($kat['id']); ?>" <?= old('id_kategori') == $kat['id'] ? 'selected' : '' ?>>
                                <?= esc($kat['nama_kategori']); ?>
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <option disabled>Data kategori tidak tersedia</option>
                <?php endif; ?>
            </select>
        </div>

        <!-- Status -->
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status">
                <option value="draft" <?= old('status') == 'draft' ? 'selected' : '' ?>>Draft</option>
                <option value="publish" <?= old('status') == 'publish' ? 'selected' : '' ?>>Publish</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Kirim</button>
    </form>
</div>
