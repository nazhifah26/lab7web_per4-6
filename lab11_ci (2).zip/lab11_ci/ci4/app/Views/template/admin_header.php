<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Portal Berita</title>
    <body>
    <div id="container">
        <header>
            <style>
                @import url('https://fonts.googleapis.com/css2?family-Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap');
                @import url('https://fonts.googleapis.com/css2?family-Open+Sans+Condensedy:ital,wght@0,300;0,700;1,300&display=swap');

                * {
                    margin: 0;
                    padding: 7px;
                }
                body {
                    line-height: 1;
                    font-size: 100%;
                    font-family: 'Open Sans', sans-serif;
                    color: #5a5a5a;
                }
                #container {
                    width: 980px;
                    margin: 0 auto;
                    box-shadow: 0 0 1em #cccccc;
                }
                header {
                    padding: 20px;
                }
                header h1 {
                    margin: 20px 10px;
                    font-size: 2em;
                    color: #b5b5b5;
                }
                nav {
                    display: block;
                    background-color: #90eb28;
                    margin-bottom: 20px;
                }
                nav a {
                    padding: 15px 20px;
                    display: inline-block;
                    color: #ffffff;
                    font-size: 14px;
                    text-decoration: none;
                    font-weight: bold;
                }
                nav a.active, nav a:hover {
                    background-color:rgb(58, 168, 43);
                }
                .table {
                    width: 100%;
                    background: #fff;
                }
                .table th, .table td {
                    border: 1px solid #1976d2;
                    padding: 10px;
                    text-align: left;
                }
                .btn {
                    margin-left: 10px;
                    padding: 7px 18px;
                    border: none;
                    border-radius: 4px;
                    font-size: 16px;
                    cursor: pointer;
                    background-color: #007bff;
                    color: #fff;
                    transition: background-color 0.3s;
                }
                .btn-danger {
                    background: #e74c3c;
                    color: #fff;
                }
                #main {
                    float: left;
                    width: 440px;
                    padding: 20px;
                }
                #sidebar {
                    float: right;
                    width: 260px;
                    padding: 50px;
                }
                .widget-box   .title {
                    padding: 10px 16px;
                    background-color: #90eb28;
                    color: #fff;
                }
                .widget-box  ul {
                    list-style-type: none;
                }
                .widget-box li a {
                    padding: 10px 16px;
                    color: #333;
                    display: block;
                    text-decoration: none;
                }
                .widget-box p {
                    padding: 15px;
                    line-height:25px;
                }
                article.entry h2 {
                    font-size: 1.5em;
                    font-weight: bold;
                    color: #222;
                    margin-top: 20px;
                }
                article.entry h2 a {
                    color: #222;
                    text-decoration: none;
                }
                article.entry p {
                    line-height: 1.6;
                    color: #555;
                }
                .pagination-box {
                    background-color: #90eb28;
                    padding: 15px;
                    display: inline-block;
                    border-radius: 1px;
                    font-weight: bold;
                    margin-bottom: 20px;
                }
                footer {
                    clear: both;
                    background-color: #1d1d1d;
                    padding: 10px;
                    color: #eee;
                }
            </style>
</head>
<body>
