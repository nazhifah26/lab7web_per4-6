<!DOCTYPE html>
<html lang="en">
<head>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
    </script>
    <script>
    $(document).ready(function(){
        $("#flip").click(function(){
            $("#panel").slideToggle("slow");
        });
    });
    </script>
    <style type="text/css">
    #panel, #flip {
        padding: 5px;
        text-align: center;
        background-color: #e5eecc;
        border:solid 1px #c3c3c3;
    }
    #panel {
        padding: 50px;
        display: none;
    }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layout Sederhana</title>
</head>
<body>
    <div id="container">
        <header>
            <h1>Layout Sederhana</h1>
            <style>
                @import url('https://fonts.googleapis.com/css2?family-Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap');
                @import url('https://fonts.googleapis.com/css2?family-Open+Sans+Condensedy:ital,wght@0,300;0,700;1,300&display=swap');

                * {
                    margin: 0;
                    padding: 7px;
                }
                body {
                    line-height: 1;
                    font-size: 100%;
                    font-family: 'Open Sans', sans-serif;
                    color: #5a5a5a;
                }
                #container {
                    width: 980px;
                    margin: 0 auto;
                    box-shadow: 0 0 1em #cccccc;
                }
                header {
                    padding: 20px;
                }
                header h1 {
                    margin: 20px 10px;
                    font-size: 2em;
                    color: #b5b5b5;
                }
                nav {
                    display: block;
                    background-color: #90eb28;
                }
                nav a {
                    padding: 15px 20px;
                    display: inline-block;
                    color: #ffffff;
                    font-size: 14px;
                    text-decoration: none;
                    font-weight: bold;
                }
                nav a.active, nav a:hover {
                    background-color:rgb(58, 168, 43);
                }
                .btn {
                    background: #888;
                    color: #fff;
                    border: none;
                    padding: 5px 10px;
                    border-radius: 3px;
                    margin-right: 5px;
                }
                .btn-danger {
                    background: #e74c3c;
                    color: #fff;
                }
                #main {
                    float: left;
                    width: 440px;
                    padding: 20px;
                }
                #sidebar {
                    float: right;
                    width: 260px;
                    padding: 50px;
                }
                .widget-box   .title {
                    padding: 10px 16px;
                    background-color: #90eb28;
                    color: #fff;
                }
                .widget-box  ul {
                    list-style-type: none;
                }
                .widget-box li a {
                    padding: 10px 16px;
                    color: #333;
                    display: block;
                    text-decoration: none;
                }
                .widget-box p {
                    padding: 15px;
                    line-height:25px;
                }
                article.entry h2 {
                    font-size: 1.5em;
                    font-weight: bold;
                    color: #222;
                    margin-top: 20px;
                }
                article.entry h2 a {
                    color: #222;
                    text-decoration: none;
                }
                article.entry p {
                    line-height: 1.6;
                    color: #555;
                }
                footer {
                    clear: both;
                    background-color: #1d1d1d;
                    padding: 20px;
                    color: #eee;
                }
            </style>
            <script>
                $(function() {
                    $("#draggable").draggable({
                        contaiment: "#containment-wrapper",
                        scroll: false
                    });
                });
            </script>
        </header>
<nav>
<a href="<?= base_url('/');?>" class="active">Home</a>
<a href="<?= base_url('/artikel');?>">Artikel</a>
<a href="<?= base_url('/about');?>">About</a>
<a href="<?= base_url('/contact');?>">Kontak</a>
</nav>
<section id="wrapper">
<section id="main"></section>