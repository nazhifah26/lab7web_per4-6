<?= $this->include('template/header'); ?>

<div id="wrapper">
    <section id="main">
        <?php if($artikel): foreach($artikel as $row): ?>
            <article class="entry">
                <h2><?= esc($row['judul']); ?></h2>
                <p><?= esc(substr($row['isi'], 0, 300)); ?>...</p>
            </article>
            <hr class="divider" />
        <?php endforeach; else: ?>
            <article class="entry">
                <h2>Belum ada data.</h2>
            </article>
        <?php endif; ?>
    </section>
</div>
<?= $this->include('template/footer'); ?>
