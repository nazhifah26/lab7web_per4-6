<ul>
<?php foreach($artikel as $row): ?>
    <li><?= esc($row['judul']); ?></li>
<?php endforeach; ?>
</ul>
