<?php
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

$routes->get('/about', 'Page::about');
$routes->get('/contact', 'Page::contact');
$routes->get('/faqs', 'Page::faqs');
$routes->get('/', 'Home::index');
$routes->get('artikel', 'Artikel::index');
$routes->get('page/tos', 'Page::tos');
$routes->get('/artikel/(:any)', 'Artikel::view/$1');
$routes->get('user/login', 'User::login');
$routes->post('user/login', 'User::login');
$routes->group('admin', function($routes) {
$routes->get('artikel', 'Artikel::admin_index');
$routes->add('artikel/add', 'Artikel::add');
$routes->add('artikel/edit/(:any)', 'Artikel::edit/$1');
$routes->get('artikel/delete/(:any)', 'Artikel::delete/$1');
    $routes->resource('post');
    $routes->resource('admin/post'); 
    $routes->get('/labvue', 'Labvue::index');
    $routes->get('admin/artikel', 'Admin\Artikel::index');
    $routes->match(['get', 'post'], 'admin/artikel/add', 'Admin\Artikel::add');
    $routes->get('admin/artikel/add', 'Admin\Artikel::add');
$routes->post('admin/artikel/add', 'Admin\Artikel::add');
$routes->get('admin/artikel', 'Admin\Artikel::admin_index');

});

