<?php
namespace App\Controllers;
use App\Models\ArtikelModel;
use App\Models\KategoriModel;
class Artikel extends BaseController
{
public function index()
{
    // Debug: tampilkan semua data POST (jika ada)
    dd($this->request->getPost()); // Ini akan berhenti di sini dan tampilkan data POST di browser

    $title = 'Daftar Artikel';
    $model = new ArtikelModel();
    $artikel = $model->getArtikelDenganKategori();

    return view('artikel/index', compact('artikel', 'title'));
}


public function admin_index()
{
$title = 'Daftar Artikel (Admin)';
$model = new ArtikelModel();
// Get search keyword
$q = $this->request->getVar('q') ?? '';
// Get category filter
$kategori_id = $this->request->getVar('kategori_id') ?? '';
$data = [
'title' => $title,
'q' => $q,
'kategori_id' => $kategori_id,
];
// Building the query
$builder = $model->table('artikel')
    ->select('artikel.*, kategori.nama_kategori')
    ->join('kategori', 'kategori.id_kategori = artikel.id_kategori', 'left');
// Apply search filter if keyword is provided
if ($q != '') {
$builder->like('artikel.judul', $q);
}
// Apply category filter if category_id is provided
if ($kategori_id != '') {
$builder->where('artikel.id_kategori', $kategori_id);
}
// Apply pagination
$data['artikel'] = $builder->paginate(10);
$data['pager'] = $model->pager;
// Fetch all categories for the filter dropdown
$kategoriModel = new KategoriModel();
$data['kategori'] = $kategoriModel->findAll();
return view('artikel/admin_index', $data);
}
public function add()
{
    $kategoriModel = new \App\Models\KategoriModel();
    $data['kategori'] = $kategoriModel->findAll(); 
    $data['title'] = 'Tambah Artikel';

    if ($this->request->getMethod() === 'post') {
        $artikelModel = new \App\Models\ArtikelModel();
        $dataPost = [
            'judul' => $this->request->getPost('judul'),
            'isi' => $this->request->getPost('isi'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'status' => $this->request->getPost('status'),
            'slug' => url_title($this->request->getPost('judul'), '-', true)
        ];
        $artikelModel->insert($dataPost);

        // Redirect ke halaman daftar artikel
        return redirect()->to('/admin/artikel');
    }

    return view('artikel/form_add', $data);
}

public function edit($id)
{
    $model = new ArtikelModel();
    $kategoriModel = new KategoriModel();

    // Jika form disubmit
    if ($this->request->getMethod() === 'post') {
        $validationRules = [
            'judul' => 'required',
            'isi' => 'required',
            'id_kategori' => 'required|integer',
            'status' => 'required|in_list[draft,publish]'
        ];

        if (!$this->validate($validationRules)) {
            // Validasi gagal, kembali ke form dengan input sebelumnya dan error
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        // Simpan perubahan data artikel
        $model->update($id, [
            'judul' => $this->request->getPost('judul'),
            'isi' => $this->request->getPost('isi'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'status' => $this->request->getPost('status')
        ]);

        return redirect()->to('/admin/artikel');
    } else {
        // GET: tampilkan form edit
        $artikel = $model->find($id);

        if (!$artikel) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Artikel dengan ID $id tidak ditemukan");
        }

        $data['artikel'] = $artikel;
        $data['kategori'] = $kategoriModel->findAll();
        $data['title'] = "Edit Artikel";

        return view('artikel/form_edit', $data);
    }
}

public function delete($id)
{
$model = new ArtikelModel();
$model->delete($id);
return redirect()->to('/admin/artikel');
}
public function view($slug)
{
$model = new ArtikelModel();
$data['artikel'] = $model->where('slug', $slug)->first();
if (empty($data['artikel'])) {
throw new \CodeIgniter\Exceptions\PageNotFoundException('Cannot

find the article.');
}
$data['title'] = $data['artikel']['judul'];
return view('artikel/detail', $data);
}
}